# Husnain Raza — Portfolio

A modern, dark-themed developer portfolio built with **Next.js 14**, **TypeScript**, and **Tailwind CSS**.

## Features
- Dark glassmorphism design with gradient accents
- Animated hero with floating orbs and cursor glow
- Sections: Hero, About, Skills, Experience, Projects, Certifications, Education, Achievements, Contact
- Fully responsive (desktop, tablet, mobile)
- Smooth scroll + reveal animations
- All data centralized in `components/data.ts` for easy editing

## Quick Start

```bash
npm install
npm run dev
# Visit http://localhost:3000
```

## Production Build

```bash
npm run build
npm start
```

## Customization

All your personal data lives in **`components/data.ts`** — edit it to update your portfolio:
- Personal info, links
- Skills and percentages
- Work experience
- Projects (add GitHub/live links)
- Certifications
- Education & achievements

### Connect Contact Form
The contact form is UI-only. To enable submissions:
1. **Formspree**: Create a form at formspree.io, replace the button `onClick` in `Contact.tsx`
2. **EmailJS**: Add `emailjs-com` package and configure in `Contact.tsx`
3. **Custom API**: POST to your own `/api/contact` Next.js route

## Deployment

Deploy instantly on **Vercel**:
```bash
npx vercel
```

Or push to GitHub and connect your repo at vercel.com.

## Placeholders to Fill
- `components/data.ts` → LinkedIn URL, project GitHub/live links, CGPA
- `Contact.tsx` → Connect a form backend
- `public/` → Add your actual photo if desired (update `About.tsx`)
