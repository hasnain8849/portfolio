"use client";
import { personal } from "./data";

export default function Footer() {
  return (
    <footer className="relative z-10 px-[6%] py-10 flex items-center justify-between flex-wrap gap-4" style={{ background: "var(--bg2)", borderTop: "1px solid var(--border)" }}>
      <div className="text-sm" style={{ color: "var(--text3)" }}>
        © {new Date().getFullYear()} Husnain Raza. Built with ❤️ and JavaScript.
      </div>
      <div className="flex gap-3">
        {[
          { label: "GH", href: personal.github, title: "GitHub" },
          { label: "in", href: personal.linkedin, title: "LinkedIn" },
          { label: "@", href: `mailto:${personal.email}`, title: "Email" },
        ].map((s) => (
          <a
            key={s.label}
            href={s.href}
            title={s.title}
            target="_blank"
            rel="noopener"
            className="w-9 h-9 rounded-lg flex items-center justify-center text-xs font-bold transition-all duration-200 hover:-translate-y-0.5"
            style={{ background: "var(--surface)", border: "1px solid var(--border)", color: "var(--text2)", textDecoration: "none" }}
            onMouseEnter={e => { (e.currentTarget.style.borderColor) = "var(--accent)"; (e.currentTarget.style.color) = "var(--accent)"; }}
            onMouseLeave={e => { (e.currentTarget.style.borderColor) = "var(--border)"; (e.currentTarget.style.color) = "var(--text2)"; }}
          >
            {s.label}
          </a>
        ))}
      </div>
    </footer>
  );
}
