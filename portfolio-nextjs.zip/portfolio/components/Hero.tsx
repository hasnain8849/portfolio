"use client";

export default function Hero() {
  return (
    <section id="hero" className="relative min-h-screen flex items-center px-[6%] pt-24 pb-16 overflow-hidden">
      {/* Orbs */}
      <div className="absolute w-[600px] h-[600px] rounded-full -top-24 -right-24 pointer-events-none" style={{ background: "radial-gradient(circle, rgba(79,124,255,0.12) 0%, transparent 70%)", animation: "float 8s ease-in-out infinite" }} />
      <div className="absolute w-[400px] h-[400px] rounded-full bottom-0 -left-24 pointer-events-none" style={{ background: "radial-gradient(circle, rgba(123,79,255,0.1) 0%, transparent 70%)", animation: "float 10s ease-in-out infinite reverse" }} />

      <div className="max-w-3xl relative z-10">
        {/* Tag */}
        <div
          className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border text-xs font-mono tracking-widest mb-8"
          style={{ border: "1px solid rgba(79,124,255,0.3)", background: "rgba(79,124,255,0.08)", color: "var(--accent)", animation: "fadeUp 0.6s ease both" }}
        >
          <span className="w-1.5 h-1.5 rounded-full" style={{ background: "var(--accent3)", animation: "pulse2 2s infinite" }} />
          Available for opportunities
        </div>

        <h1
          className="font-syne font-extrabold leading-[1.05] tracking-tight mb-4"
          style={{ fontSize: "clamp(3rem, 7vw, 5.5rem)", animation: "fadeUp 0.6s 0.1s ease both" }}
        >
          Husnain<br />
          <span style={{ background: "linear-gradient(135deg,#4f7cff 0%,#7b4fff 50%,#00d4aa 100%)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>Raza</span>
        </h1>

        <p className="font-mono mb-6" style={{ fontSize: "clamp(1rem,2vw,1.2rem)", color: "var(--text2)", animation: "fadeUp 0.6s 0.2s ease both" }}>
          Senior JavaScript Developer <span style={{ color: "var(--accent3)" }}>/ Full Stack Specialist</span>
        </p>

        <p className="max-w-xl leading-relaxed mb-10" style={{ fontSize: "1.05rem", color: "var(--text2)", animation: "fadeUp 0.6s 0.3s ease both" }}>
          Building high-performance web applications with 4+ years of expertise in the React ecosystem and Node.js. Crafting scalable solutions that drive real business impact.
        </p>

        <div className="flex gap-4 flex-wrap" style={{ animation: "fadeUp 0.6s 0.4s ease both" }}>
          <a
            href="#projects"
            className="inline-flex items-center gap-2 px-7 py-3.5 rounded-lg font-semibold text-sm text-white transition-all duration-300 hover:-translate-y-0.5"
            style={{ background: "linear-gradient(135deg,#4f7cff,#7b4fff)", boxShadow: "0 0 30px rgba(79,124,255,0.3)" }}
            onMouseEnter={e => (e.currentTarget.style.boxShadow = "0 0 50px rgba(79,124,255,0.5)")}
            onMouseLeave={e => (e.currentTarget.style.boxShadow = "0 0 30px rgba(79,124,255,0.3)")}
          >
            View Projects →
          </a>
          <a
            href="#contact"
            className="inline-flex items-center gap-2 px-7 py-3.5 rounded-lg font-medium text-sm transition-all duration-300 hover:-translate-y-0.5"
            style={{ border: "1px solid var(--border2)", background: "var(--surface)", color: "var(--text)", backdropFilter: "blur(10px)" }}
            onMouseEnter={e => { (e.currentTarget.style.borderColor = "var(--accent)"); (e.currentTarget.style.color = "var(--accent)"); }}
            onMouseLeave={e => { (e.currentTarget.style.borderColor = "var(--border2)"); (e.currentTarget.style.color = "var(--text)"); }}
          >
            Get In Touch
          </a>
        </div>

        {/* Stats */}
        <div className="flex gap-10 flex-wrap mt-14 pt-8" style={{ borderTop: "1px solid var(--border)", animation: "fadeUp 0.6s 0.5s ease both" }}>
          {[["4+","Years Exp."],["50K+","Users Served"],["15+","Projects"],["4","Certifications"]].map(([num, label]) => (
            <div key={label}>
              <div className="font-syne font-extrabold text-4xl" style={{ background: "linear-gradient(135deg,#4f7cff,#00d4aa)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>{num}</div>
              <div className="text-xs uppercase tracking-widest mt-0.5" style={{ color: "var(--text3)" }}>{label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2" style={{ color: "var(--text3)", fontSize: "0.7rem", letterSpacing: "0.1em", textTransform: "uppercase" }}>
        <span>Scroll</span>
        <div className="w-px h-10 origin-top" style={{ background: "linear-gradient(to bottom, var(--accent), transparent)", animation: "scrollLine 2s ease-in-out infinite" }} />
      </div>
    </section>
  );
}
