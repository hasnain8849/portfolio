// About.tsx
"use client";
import { personal } from "./data";

export default function About() {
  return (
    <section id="about" className="relative z-10" style={{ background: "var(--bg2)" }}>
      <div className="px-[6%] py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          {/* Avatar - hidden on mobile */}
          <div className="hidden md:block relative">
            <div
              className="w-full max-w-[360px] aspect-square rounded-2xl flex items-center justify-center font-syne font-extrabold text-8xl relative overflow-hidden"
              style={{ background: "linear-gradient(135deg,rgba(79,124,255,0.15),rgba(123,79,255,0.15))", border: "1px solid var(--border2)", color: "var(--accent)" }}
            >
              <span className="relative z-10">HR</span>
              <div className="absolute inset-0" style={{ background: "linear-gradient(135deg,rgba(79,124,255,0.1),rgba(0,212,170,0.05))" }} />
            </div>
            <div
              className="absolute -bottom-3 -right-3 px-4 py-2.5 rounded-xl text-sm font-bold text-white"
              style={{ background: "linear-gradient(135deg,var(--accent),var(--accent2))", boxShadow: "0 8px 24px rgba(79,124,255,0.4)" }}
            >
              🚀 Open to Work
            </div>
          </div>

          {/* Text */}
          <div>
            <div className="section-label">About Me</div>
            <h2 className="font-syne font-extrabold text-5xl tracking-tight mb-4" style={{ lineHeight: 1.1 }}>Crafting Digital<br />Experiences</h2>
            <p className="mb-4 leading-relaxed" style={{ color: "var(--text2)" }}>
              I'm a Senior JavaScript Developer based in Lahore, Pakistan, with 4+ years of hands-on experience building scalable, high-performance web applications. I specialize in the React ecosystem and Node.js backend development.
            </p>
            <p className="mb-4 leading-relaxed" style={{ color: "var(--text2)" }}>
              Currently leading a team of 5 developers at TechVision Solutions, architecting modern SaaS platforms serving 50,000+ monthly active users.
            </p>
            <p className="mb-6 leading-relaxed" style={{ color: "var(--text2)" }}>
              My thesis on "Optimizing React Performance for Emerging Markets" reflects my passion for making the web fast and accessible for everyone.
            </p>
            <div className="grid grid-cols-2 gap-3">
              {[
                ["Location", personal.location],
                ["Experience", "4+ Years"],
                ["Specialization", "React / Node.js"],
                ["Status", "Open to Work ✓", "var(--accent3)"],
              ].map(([label, val, color]) => (
                <div key={label} className="flex flex-col gap-0.5 p-3 rounded-xl" style={{ background: "var(--surface)", border: "1px solid var(--border)" }}>
                  <span className="text-[0.68rem] uppercase tracking-widest" style={{ color: "var(--text3)" }}>{label}</span>
                  <span className="text-sm font-medium" style={{ color: color || "var(--text)" }}>{val}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
