"use client";
import { projects } from "./data";

export default function Projects() {
  return (
    <section id="projects" className="relative z-10" style={{ background: "var(--bg)" }}>
      <div className="px-[6%] py-24">
        <div className="section-label">Featured Work</div>
        <h2 className="font-syne font-extrabold text-5xl tracking-tight mb-3">Key Projects</h2>
        <p className="mb-14 max-w-xl" style={{ color: "var(--text2)" }}>Selected projects showcasing engineering depth and measurable business results.</p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((p, i) => (
            <div
              key={p.title}
              className="p-7 rounded-2xl relative overflow-hidden transition-all duration-300 cursor-default group"
              style={{ background: "var(--surface)", border: "1px solid var(--border)" }}
              onMouseEnter={e => {
                (e.currentTarget.style.transform) = "translateY(-8px)";
                (e.currentTarget.style.borderColor) = "rgba(79,124,255,0.3)";
                (e.currentTarget.style.boxShadow) = "0 30px 60px rgba(0,0,0,0.3),0 0 0 1px rgba(79,124,255,0.1)";
              }}
              onMouseLeave={e => {
                (e.currentTarget.style.transform) = "translateY(0)";
                (e.currentTarget.style.borderColor) = "var(--border)";
                (e.currentTarget.style.boxShadow) = "none";
              }}
            >
              {/* Hover glow */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"
                style={{ background: "linear-gradient(135deg,rgba(79,124,255,0.06),rgba(123,79,255,0.04))" }} />

              <div className="flex items-start justify-between mb-4 relative z-10">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center text-2xl"
                  style={{ background: "linear-gradient(135deg,rgba(79,124,255,0.2),rgba(123,79,255,0.2))", border: "1px solid rgba(79,124,255,0.2)" }}>
                  {p.icon}
                </div>
                <span className="font-mono text-xs" style={{ color: "var(--text3)" }}>{p.year}</span>
              </div>

              <h3 className="font-syne font-bold text-xl mb-3 relative z-10">{p.title}</h3>
              <p className="text-sm leading-relaxed mb-4 relative z-10" style={{ color: "var(--text2)" }}>{p.description}</p>

              <div className="flex flex-wrap gap-3 mb-4 relative z-10">
                {p.metrics.map((m) => (
                  <span key={m} className="font-mono text-xs flex items-center gap-1" style={{ color: "var(--accent3)" }}>
                    <span className="text-[0.65rem]">↑</span>{m}
                  </span>
                ))}
              </div>

              <div className="flex flex-wrap gap-1.5 relative z-10">
                {p.stack.map((s) => (
                  <span key={s} className="px-2.5 py-0.5 rounded-full font-mono text-[0.72rem]"
                    style={{ background: "rgba(79,124,255,0.08)", border: "1px solid rgba(79,124,255,0.2)", color: "var(--accent)" }}>
                    {s}
                  </span>
                ))}
              </div>

              {/* Links — show if provided */}
              {(p.github || p.live) && (
                <div className="flex gap-3 mt-4 relative z-10">
                  {p.github && <a href={p.github} target="_blank" rel="noopener" className="text-xs font-medium transition-colors hover:text-white" style={{ color: "var(--text3)" }}>GitHub ↗</a>}
                  {p.live && <a href={p.live} target="_blank" rel="noopener" className="text-xs font-medium transition-colors hover:text-white" style={{ color: "var(--text3)" }}>Live Demo ↗</a>}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
