"use client";
import { useState, useEffect } from "react";
import { Menu, X } from "lucide-react";

const links = ["About","Skills","Experience","Projects","Certifications","Contact"];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      <nav
        className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-[6%] h-[68px] transition-all duration-300"
        style={{
          background: scrolled ? "rgba(8,12,20,0.97)" : "rgba(8,12,20,0.85)",
          backdropFilter: "blur(20px)",
          borderBottom: "1px solid var(--border)",
        }}
      >
        <a
          href="#hero"
          className="font-syne font-extrabold text-xl"
          style={{ background: "linear-gradient(135deg,#4f7cff,#7b4fff)", WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}
        >
          HR.
        </a>
        <ul className="hidden md:flex gap-8 list-none">
          {links.map((l) => (
            <li key={l}>
              <a
                href={`#${l.toLowerCase()}`}
                className="text-[0.85rem] font-medium tracking-[0.04em] uppercase transition-colors duration-200 hover:text-white relative group"
                style={{ color: "var(--text2)" }}
              >
                {l}
                <span className="absolute -bottom-1 left-0 w-full h-px scale-x-0 group-hover:scale-x-100 transition-transform origin-left" style={{ background: "var(--accent)" }} />
              </a>
            </li>
          ))}
          <li>
            <a
              href="#contact"
              className="px-5 py-2 rounded-md border text-sm font-medium transition-all duration-200"
              style={{ border: "1px solid var(--accent)", color: "var(--accent)" }}
              onMouseEnter={e => { (e.target as HTMLElement).style.background = "var(--accent)"; (e.target as HTMLElement).style.color = "#080c14"; }}
              onMouseLeave={e => { (e.target as HTMLElement).style.background = "transparent"; (e.target as HTMLElement).style.color = "var(--accent)"; }}
            >
              Hire Me
            </a>
          </li>
        </ul>
        <button className="md:hidden p-1" style={{ color: "var(--text2)" }} onClick={() => setOpen(true)}>
          <Menu size={22} />
        </button>
      </nav>

      {/* Mobile Nav Overlay */}
      {open && (
        <div className="fixed inset-0 z-[99] flex flex-col items-center justify-center gap-8" style={{ background: "rgba(8,12,20,0.98)", backdropFilter: "blur(20px)" }}>
          <button className="absolute top-6 right-[6%]" style={{ color: "var(--text2)" }} onClick={() => setOpen(false)}>
            <X size={24} />
          </button>
          {links.map((l) => (
            <a
              key={l}
              href={`#${l.toLowerCase()}`}
              onClick={() => setOpen(false)}
              className="font-syne text-4xl font-bold transition-colors duration-200 hover:text-[var(--accent)]"
            >
              {l}
            </a>
          ))}
        </div>
      )}
    </>
  );
}
