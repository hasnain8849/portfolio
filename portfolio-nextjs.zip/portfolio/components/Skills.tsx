"use client";
import { skills } from "./data";

const colorMap: Record<string, { from: string; to: string }> = {
  blue:   { from: "#4f7cff", to: "#7b4fff" },
  purple: { from: "#7b4fff", to: "#a855f7" },
  green:  { from: "#00d4aa", to: "#059669" },
  red:    { from: "#ff6b6b", to: "#dc2626" },
};

const iconBg: Record<string, string> = {
  blue:   "rgba(79,124,255,0.15)",
  purple: "rgba(123,79,255,0.15)",
  green:  "rgba(0,212,170,0.12)",
  red:    "rgba(255,107,107,0.12)",
};
const iconColor: Record<string, string> = {
  blue: "#4f7cff", purple: "#7b4fff", green: "#00d4aa", red: "#ff6b6b",
};

export default function Skills() {
  return (
    <section id="skills" className="relative z-10" style={{ background: "var(--bg)" }}>
      <div className="px-[6%] py-24">
        <div className="section-label">Technical Skills</div>
        <h2 className="font-syne font-extrabold text-5xl tracking-tight mb-3">My Tech Stack</h2>
        <p className="mb-14 max-w-xl" style={{ color: "var(--text2)" }}>A full-stack toolkit honed over 4+ years across production-grade applications.</p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {skills.map((cat) => (
            <div
              key={cat.category}
              className="p-7 rounded-2xl relative overflow-hidden transition-all duration-300 group cursor-default"
              style={{ background: "var(--surface)", border: "1px solid var(--border)" }}
              onMouseEnter={e => { (e.currentTarget.style.borderColor = "var(--border2)"); (e.currentTarget.style.transform) = "translateY(-4px)"; (e.currentTarget.style.boxShadow) = "0 20px 40px rgba(0,0,0,0.3)"; }}
              onMouseLeave={e => { (e.currentTarget.style.borderColor = "var(--border)"); (e.currentTarget.style.transform) = "translateY(0)"; (e.currentTarget.style.boxShadow) = "none"; }}
            >
              {/* Top accent line */}
              <div className="absolute top-0 left-0 right-0 h-0.5 scale-x-0 group-hover:scale-x-100 transition-transform origin-left duration-300"
                style={{ background: `linear-gradient(90deg,${colorMap[cat.color].from},${colorMap[cat.color].to})` }} />

              <div className="w-11 h-11 rounded-xl flex items-center justify-center text-xl mb-4"
                style={{ background: iconBg[cat.color], color: iconColor[cat.color] }}>
                {cat.icon}
              </div>
              <div className="font-syne font-bold mb-4">{cat.category}</div>

              {/* Bar skills */}
              {cat.items?.map((item, i) => (
                <div key={item.name} className="mb-3">
                  <div className="flex justify-between mb-1.5">
                    <span className="text-sm font-medium">{item.name}</span>
                    <span className="font-mono text-xs" style={{ color: colorMap[cat.color].from }}>{item.pct}%</span>
                  </div>
                  <div className="h-1 rounded-full overflow-hidden" style={{ background: "rgba(255,255,255,0.06)" }}>
                    <div
                      className="h-full rounded-full origin-left"
                      style={{
                        width: `${item.pct}%`,
                        background: `linear-gradient(90deg,${colorMap[cat.color].from},${colorMap[cat.color].to})`,
                        animation: `growBar 1.2s ${i * 0.1}s ease both`,
                      }}
                    />
                  </div>
                </div>
              ))}

              {/* Tag skills */}
              {cat.tags && (
                <div className="flex flex-wrap gap-2 mt-1">
                  {cat.tags.map((tag) => (
                    <span
                      key={tag}
                      className="px-3 py-1 rounded-full text-[0.76rem] font-medium cursor-default transition-all duration-200"
                      style={{ background: "rgba(255,255,255,0.05)", border: "1px solid var(--border)", color: "var(--text2)" }}
                      onMouseEnter={e => { (e.currentTarget.style.borderColor) = colorMap[cat.color].from; (e.currentTarget.style.color) = colorMap[cat.color].from; }}
                      onMouseLeave={e => { (e.currentTarget.style.borderColor) = "var(--border)"; (e.currentTarget.style.color) = "var(--text2)"; }}
                    >
                      {tag}
                    </span>
                  ))}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
