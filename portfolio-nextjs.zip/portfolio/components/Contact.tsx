"use client";
import { personal } from "./data";
import { useState } from "react";

export default function Contact() {
  const [sent, setSent] = useState(false);

  return (
    <section id="contact" className="relative z-10" style={{ background: "var(--bg)" }}>
      <div className="px-[6%] py-24">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-20 items-start">
          {/* Left */}
          <div>
            <div className="section-label">Let's Connect</div>
            <h2 className="font-syne font-extrabold text-5xl tracking-tight mb-4">Get In <span style={{ color: "var(--accent)" }}>Touch</span></h2>
            <p className="mb-8 leading-relaxed" style={{ color: "var(--text2)" }}>Have a project in mind or want to discuss opportunities? I'm always open to interesting conversations and collaboration.</p>

            <div className="space-y-3">
              {[
                { icon: "📧", label: "Email", val: personal.email, href: `mailto:${personal.email}`, bg: "rgba(79,124,255,0.15)" },
                { icon: "📱", label: "Phone", val: personal.phone, href: `tel:${personal.phone.replace(/-/g,"")}`, bg: "rgba(0,212,170,0.12)" },
                { icon: "🐙", label: "GitHub", val: "github.com/husnain-dev", href: personal.github, bg: "rgba(255,255,255,0.08)" },
                { icon: "📍", label: "Location", val: personal.location, href: undefined, bg: "rgba(255,107,107,0.12)" },
              ].map((item) => {
                const Wrapper = item.href ? "a" : "div";
                return (
                  <Wrapper
                    key={item.label}
                    {...(item.href ? { href: item.href, target: "_blank", rel: "noopener" } : {})}
                    className="flex items-center gap-4 p-4 rounded-xl transition-all duration-300 no-underline"
                    style={{ background: "var(--surface)", border: "1px solid var(--border)", color: "var(--text)", cursor: item.href ? "pointer" : "default" }}
                    onMouseEnter={e => { if (item.href) { (e.currentTarget.style.borderColor) = "var(--accent)"; (e.currentTarget.style.transform) = "translateX(6px)"; }}}
                    onMouseLeave={e => { (e.currentTarget.style.borderColor) = "var(--border)"; (e.currentTarget.style.transform) = "translateX(0)"; }}
                  >
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center text-lg flex-shrink-0" style={{ background: item.bg }}>{item.icon}</div>
                    <div>
                      <div className="text-[0.68rem] uppercase tracking-widest" style={{ color: "var(--text3)" }}>{item.label}</div>
                      <div className="text-sm font-medium">{item.val}</div>
                    </div>
                  </Wrapper>
                );
              })}
            </div>
          </div>

          {/* Form */}
          <div className="flex flex-col gap-4">
            <div className="grid grid-cols-2 gap-4">
              {["First Name", "Last Name"].map((p) => (
                <div key={p} className="flex flex-col gap-2">
                  <label className="text-xs font-medium" style={{ color: "var(--text2)" }}>{p}</label>
                  <input
                    type="text" placeholder={p === "First Name" ? "John" : "Doe"}
                    className="px-4 py-3 rounded-xl text-sm outline-none transition-all duration-200"
                    style={{ background: "var(--surface2)", border: "1px solid var(--border)", color: "var(--text)", fontFamily: "inherit" }}
                    onFocus={e => { e.currentTarget.style.borderColor = "var(--accent)"; e.currentTarget.style.boxShadow = "0 0 0 3px rgba(79,124,255,0.15)"; }}
                    onBlur={e => { e.currentTarget.style.borderColor = "var(--border)"; e.currentTarget.style.boxShadow = "none"; }}
                  />
                </div>
              ))}
            </div>
            {[
              { label: "Email Address", type: "email", placeholder: "john@company.com" },
              { label: "Subject", type: "text", placeholder: "Project Inquiry / Collaboration" },
            ].map((f) => (
              <div key={f.label} className="flex flex-col gap-2">
                <label className="text-xs font-medium" style={{ color: "var(--text2)" }}>{f.label}</label>
                <input
                  type={f.type} placeholder={f.placeholder}
                  className="px-4 py-3 rounded-xl text-sm outline-none transition-all duration-200"
                  style={{ background: "var(--surface2)", border: "1px solid var(--border)", color: "var(--text)", fontFamily: "inherit" }}
                  onFocus={e => { e.currentTarget.style.borderColor = "var(--accent)"; e.currentTarget.style.boxShadow = "0 0 0 3px rgba(79,124,255,0.15)"; }}
                  onBlur={e => { e.currentTarget.style.borderColor = "var(--border)"; e.currentTarget.style.boxShadow = "none"; }}
                />
              </div>
            ))}
            <div className="flex flex-col gap-2">
              <label className="text-xs font-medium" style={{ color: "var(--text2)" }}>Message</label>
              <textarea
                rows={5} placeholder="Tell me about your project or opportunity…"
                className="px-4 py-3 rounded-xl text-sm outline-none transition-all duration-200 resize-y"
                style={{ background: "var(--surface2)", border: "1px solid var(--border)", color: "var(--text)", fontFamily: "inherit" }}
                onFocus={e => { e.currentTarget.style.borderColor = "var(--accent)"; e.currentTarget.style.boxShadow = "0 0 0 3px rgba(79,124,255,0.15)"; }}
                onBlur={e => { e.currentTarget.style.borderColor = "var(--border)"; e.currentTarget.style.boxShadow = "none"; }}
              />
            </div>
            <button
              onClick={() => setSent(true)}
              className="w-full py-3.5 rounded-xl font-semibold text-sm text-white transition-all duration-300 hover:-translate-y-0.5"
              style={{ background: "linear-gradient(135deg,var(--accent),var(--accent2))", boxShadow: "0 0 30px rgba(79,124,255,0.3)" }}
            >
              {sent ? "Message Sent ✓ (Connect a backend to enable)" : "Send Message →"}
            </button>
            <p className="text-center text-xs" style={{ color: "var(--text3)" }}>
              ⚡ [Placeholder] Connect to Formspree / EmailJS / your API for live submissions
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
