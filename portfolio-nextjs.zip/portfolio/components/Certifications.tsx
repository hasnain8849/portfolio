// Certifications.tsx
"use client";
import { certifications } from "./data";

export default function Certifications() {
  return (
    <section id="certifications" className="relative z-10" style={{ background: "var(--bg2)" }}>
      <div className="px-[6%] py-24">
        <div className="section-label">Credentials</div>
        <h2 className="font-syne font-extrabold text-5xl tracking-tight mb-3">Certifications</h2>
        <p className="mb-14 max-w-xl" style={{ color: "var(--text2)" }}>Industry-recognized credentials validating expertise across cloud and development.</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          {certifications.map((c) => (
            <div key={c.name}
              className="flex gap-4 items-start p-6 rounded-2xl transition-all duration-300"
              style={{ background: "var(--surface)", border: "1px solid var(--border)" }}
              onMouseEnter={e => { (e.currentTarget.style.borderColor) = "var(--border2)"; (e.currentTarget.style.transform) = "translateY(-3px)"; }}
              onMouseLeave={e => { (e.currentTarget.style.borderColor) = "var(--border)"; (e.currentTarget.style.transform) = "translateY(0)"; }}
            >
              <div className="w-11 h-11 rounded-xl flex items-center justify-center font-syne font-extrabold text-sm flex-shrink-0"
                style={{ background: c.bg, color: c.color }}>
                {c.abbr}
              </div>
              <div>
                <div className="font-semibold text-sm mb-0.5">{c.name}</div>
                <div className="text-xs mb-1.5" style={{ color: "var(--text3)" }}>{c.issuer}</div>
                <div className="font-mono text-xs" style={{ color: "var(--accent)" }}>{c.year}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
