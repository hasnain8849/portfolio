// Experience.tsx
"use client";
import { experiences } from "./data";

export default function Experience() {
  return (
    <section id="experience" className="relative z-10" style={{ background: "var(--bg2)" }}>
      <div className="px-[6%] py-24">
        <div className="section-label">Work History</div>
        <h2 className="font-syne font-extrabold text-5xl tracking-tight mb-3">Experience</h2>
        <p className="mb-14 max-w-xl" style={{ color: "var(--text2)" }}>A track record of delivering impact across products and teams.</p>

        <div className="relative max-w-3xl">
          {/* Timeline line */}
          <div className="absolute left-[11px] top-2 bottom-0 w-px" style={{ background: "linear-gradient(to bottom, var(--accent), transparent)" }} />

          {experiences.map((exp, i) => (
            <div key={exp.role} className="relative pl-14 pb-12">
              {/* Dot */}
              <div
                className="absolute left-0.5 top-1.5 w-5 h-5 rounded-full border-2 flex items-center justify-center"
                style={{ borderColor: exp.current ? "var(--accent3)" : "var(--accent)", background: "var(--bg2)" }}
              >
                <div className="w-2 h-2 rounded-full" style={{ background: exp.current ? "var(--accent3)" : "var(--accent)", boxShadow: exp.current ? "0 0 8px var(--accent3)" : "none" }} />
              </div>

              <div
                className="p-6 rounded-2xl transition-all duration-300"
                style={{ background: "var(--surface)", border: "1px solid var(--border)" }}
                onMouseEnter={e => { (e.currentTarget.style.borderColor) = "var(--border2)"; (e.currentTarget.style.boxShadow) = "0 10px 30px rgba(0,0,0,0.2)"; }}
                onMouseLeave={e => { (e.currentTarget.style.borderColor) = "var(--border)"; (e.currentTarget.style.boxShadow) = "none"; }}
              >
                <div className="flex items-start justify-between flex-wrap gap-2 mb-1.5">
                  <span className="font-syne font-bold text-lg">{exp.role}</span>
                  <span
                    className="font-mono text-xs px-2.5 py-1 rounded-full whitespace-nowrap"
                    style={{ background: exp.current ? "rgba(0,212,170,0.1)" : "rgba(79,124,255,0.1)", color: exp.current ? "var(--accent3)" : "var(--accent)" }}
                  >
                    {exp.period}
                  </span>
                </div>
                <div className="text-sm mb-4" style={{ color: "var(--text3)" }}>{exp.company} · {exp.location}</div>
                <ul className="space-y-1.5">
                  {exp.bullets.map((b) => (
                    <li key={b} className="text-sm relative pl-5" style={{ color: "var(--text2)" }}>
                      <span className="absolute left-0" style={{ color: "var(--accent3)" }}>▹</span>
                      {b}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
