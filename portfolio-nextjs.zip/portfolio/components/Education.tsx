"use client";
import { education } from "./data";

export default function Education() {
  return (
    <section id="education" className="relative z-10" style={{ background: "var(--bg)" }}>
      <div className="px-[6%] py-24">
        <div className="section-label">Academic Background</div>
        <h2 className="font-syne font-extrabold text-5xl tracking-tight mb-10">Education</h2>
        <div
          className="max-w-2xl flex gap-6 items-start p-9 rounded-2xl relative overflow-hidden"
          style={{ background: "var(--surface)", border: "1px solid var(--border)" }}
        >
          <div className="absolute -top-14 -right-14 w-44 h-44 rounded-full pointer-events-none"
            style={{ background: "radial-gradient(circle, rgba(79,124,255,0.08), transparent 70%)" }} />
          <div className="w-15 h-15 min-w-[60px] min-h-[60px] rounded-2xl flex items-center justify-center text-3xl"
            style={{ background: "linear-gradient(135deg,rgba(79,124,255,0.2),rgba(123,79,255,0.2))", border: "1px solid rgba(79,124,255,0.2)" }}>
            🎓
          </div>
          <div>
            <div className="font-syne font-bold text-2xl mb-1">{education.degree}</div>
            <div className="text-sm mb-1" style={{ color: "var(--accent)" }}>{education.school}</div>
            <div className="font-mono text-xs mb-4" style={{ color: "var(--text3)" }}>{education.period}</div>
            <ul className="space-y-1.5">
              {education.points.map((p) => (
                <li key={p} className="text-sm relative pl-5" style={{ color: "var(--text2)" }}>
                  <span className="absolute left-0" style={{ color: "var(--accent3)" }}>▹</span>{p}
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </section>
  );
}
