// ============================================================
// PORTFOLIO DATA — Edit this file to update your portfolio
// ============================================================

export const personal = {
  name: "Husnain Raza",
  title: "Senior JavaScript Developer | Full Stack Specialist",
  email: "ha7920488@gmail.com",
  phone: "0310-6163226",
  location: "Lahore, Pakistan",
  github: "https://github.com/husnain-dev",
  linkedin: "https://linkedin.com/in/husnain-raza", // [PLACEHOLDER - update with real URL]
  twitter: "", // [PLACEHOLDER - add if you have one]
  summary: "Innovative JavaScript Developer with 4+ years of experience building scalable web applications. Specialized in React ecosystem and Node.js backend development. Proven track record of delivering high-performance solutions that drive business growth.",
};

export const stats = [
  { value: "4+", label: "Years Exp." },
  { value: "50K+", label: "Users Served" },
  { value: "15+", label: "Projects" },
  { value: "4", label: "Certifications" },
];

export const skills = [
  {
    category: "Frontend Mastery",
    icon: "⚛",
    color: "blue",
    items: [
      { name: "React.js", pct: 95 },
      { name: "Next.js", pct: 92 },
      { name: "TypeScript", pct: 88 },
      { name: "Redux Toolkit", pct: 90 },
    ],
  },
  {
    category: "Backend Expertise",
    icon: "⬡",
    color: "purple",
    items: [
      { name: "Node.js", pct: 90 },
      { name: "Express.js", pct: 88 },
      { name: "GraphQL", pct: 85 },
      { name: "REST APIs", pct: 93 },
    ],
  },
  {
    category: "Database & DevOps",
    icon: "🗄",
    color: "green",
    tags: ["MongoDB", "PostgreSQL", "Docker", "AWS", "CI/CD", "Microservices", "Redis"],
  },
  {
    category: "Testing & Tools",
    icon: "🧪",
    color: "red",
    tags: ["Jest", "Cypress", "Git", "Webpack", "WebSocket", "Firebase", "OpenAI API"],
  },
];

export const experiences = [
  {
    role: "Senior Frontend Developer",
    company: "TechVision Solutions",
    location: "Lahore",
    period: "Mar 2024 – Present",
    current: true,
    bullets: [
      "Lead a team of 5 developers building a SaaS platform with 50,000+ monthly active users",
      "Architected migration from legacy AngularJS to Next.js, improving performance by 65%",
      "Implemented micro-frontend architecture reducing build times by 40%",
      "Introduced GraphQL API layer decreasing data over-fetching by 75%",
      "Mentored junior developers through code reviews and pair programming sessions",
    ],
  },
  {
    role: "Full Stack JavaScript Developer",
    company: "Digital Innovations Pakistan",
    location: "Lahore",
    period: "Jun 2023 – Feb 2024",
    current: false,
    bullets: [
      "Developed 15+ React components used across 3 enterprise applications",
      "Built Node.js microservices handling 10,000+ requests per minute",
      "Optimized MongoDB queries reducing database load by 55%",
      "Implemented CI/CD pipeline reducing deployment time from 30 to 5 minutes",
      "Created comprehensive unit test coverage increasing from 40% to 90%",
    ],
  },
  {
    role: "JavaScript Developer",
    company: "WebCraft Studios",
    location: "Lahore",
    period: "Jan 2022 – May 2023",
    current: false,
    bullets: [
      "Developed 8 production-ready React applications for international clients",
      "Integrated third-party APIs including PayPal, Google Maps, and Twilio",
      "Reduced bundle size by 30% through code splitting and lazy loading",
      "Implemented Redux state management across all applications",
      "Conducted weekly knowledge-sharing sessions for team members",
    ],
  },
];

export const projects = [
  {
    icon: "📊",
    title: "E-Commerce Analytics Dashboard",
    year: "2024",
    description: "Real-time analytics dashboard processing 1M+ daily transactions with live WebSocket data updates and multi-gateway integration.",
    metrics: ["Load time 8s → 1.2s", "1M+ daily txns"],
    stack: ["Next.js", "TypeScript", "GraphQL", "MongoDB", "WebSocket"],
    github: "", // [PLACEHOLDER - add GitHub link]
    live: "",   // [PLACEHOLDER - add live demo link]
  },
  {
    icon: "🏥",
    title: "Healthcare Management System",
    year: "2023",
    description: "HIPAA-compliant patient management system deployed across 50+ clinics, with role-based access control and PDF reporting.",
    metrics: ["90% scheduling error reduction", "50+ clinics"],
    stack: ["React", "Redux", "Node.js", "PostgreSQL", "JWT"],
    github: "",
    live: "",
  },
  {
    icon: "🤖",
    title: "AI-Powered Chat Platform",
    year: "2023",
    description: "Real-time chat application with GPT-3.5 integration for response suggestions and AI-powered sentiment analysis moderation.",
    metrics: ["70% toxic message reduction", "10K+ concurrent users"],
    stack: ["React", "Firebase", "OpenAI API", "GPT-3.5"],
    github: "",
    live: "",
  },
];

export const certifications = [
  { name: "AWS Certified Developer – Associate", issuer: "Amazon Web Services", year: "2024", abbr: "AWS", color: "#ff9900", bg: "rgba(255,153,0,0.15)" },
  { name: "Google Professional Cloud Developer", issuer: "Google Cloud", year: "2023", abbr: "GCP", color: "#4285f4", bg: "rgba(66,133,244,0.15)" },
  { name: "React Advanced Certification", issuer: "Frontend Masters", year: "2023", abbr: "FM", color: "#61dafb", bg: "rgba(97,218,251,0.15)" },
  { name: "Node.js Services Development", issuer: "Microsoft", year: "2022", abbr: "MS", color: "#0078d4", bg: "rgba(0,120,212,0.15)" },
];

export const education = {
  degree: "BS Information Technology",
  school: "Lahore Garrison University, Lahore",
  period: "2021 – 2025",
  points: [
    'Thesis: "Optimizing React Performance for Emerging Markets"',
    "President of Computer Science Society",
    "CGPA: [Placeholder — add your CGPA]",
  ],
};

export const achievements = [
  { icon: "🏆", title: "Performance Optimization Award", desc: "Recognized by TechVision Solutions for reducing application bundle size by 40% across all projects in 2024." },
  { icon: "📦", title: "Open Source Contributor", desc: "Maintained a popular React hook library with 5,000+ weekly npm downloads — actively used in production apps worldwide." },
  { icon: "🎤", title: "Tech Speaker", desc: 'Presented "Modern State Management in React" at PakistanJS Conference 2023 to an audience of 300+ developers.' },
];
