"use client";
import { achievements } from "./data";

export default function Achievements() {
  return (
    <section id="achievements" className="relative z-10" style={{ background: "var(--bg2)" }}>
      <div className="px-[6%] py-24">
        <div className="section-label">Recognition</div>
        <h2 className="font-syne font-extrabold text-5xl tracking-tight mb-10">Achievements</h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
          {achievements.map((a) => (
            <div key={a.title}
              className="p-6 rounded-2xl transition-all duration-300"
              style={{ background: "var(--surface)", border: "1px solid var(--border)" }}
              onMouseEnter={e => { (e.currentTarget.style.borderColor) = "var(--border2)"; (e.currentTarget.style.transform) = "translateY(-3px)"; }}
              onMouseLeave={e => { (e.currentTarget.style.borderColor) = "var(--border)"; (e.currentTarget.style.transform) = "translateY(0)"; }}
            >
              <div className="text-4xl mb-4">{a.icon}</div>
              <div className="font-syne font-bold mb-2">{a.title}</div>
              <div className="text-sm leading-relaxed" style={{ color: "var(--text2)" }}>{a.desc}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
