import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        syne: ["Syne", "sans-serif"],
        manrope: ["Manrope", "sans-serif"],
        mono: ["DM Mono", "monospace"],
      },
      colors: {
        bg: {
          DEFAULT: "#080c14",
          2: "#0d1320",
          3: "#111827",
        },
        accent: {
          DEFAULT: "#4f7cff",
          2: "#7b4fff",
          3: "#00d4aa",
          4: "#ff6b6b",
        },
      },
      animation: {
        float: "float 8s ease-in-out infinite",
        pulse2: "pulse2 2s ease-in-out infinite",
        fadeUp: "fadeUp 0.6s ease both",
        growBar: "growBar 1.2s ease both",
        scrollLine: "scrollLine 2s ease-in-out infinite",
      },
      keyframes: {
        float: {
          "0%, 100%": { transform: "translateY(0) scale(1)" },
          "50%": { transform: "translateY(-30px) scale(1.05)" },
        },
        pulse2: {
          "0%, 100%": { opacity: "1", transform: "scale(1)" },
          "50%": { opacity: "0.5", transform: "scale(0.8)" },
        },
        fadeUp: {
          from: { opacity: "0", transform: "translateY(20px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
        growBar: {
          from: { transform: "scaleX(0)" },
          to: { transform: "scaleX(1)" },
        },
        scrollLine: {
          "0%, 100%": { transform: "scaleY(1)", opacity: "1" },
          "50%": { transform: "scaleY(0.5)", opacity: "0.4" },
        },
      },
    },
  },
  plugins: [],
};

export default config;
