import type { Metadata } from "next";
import { Syne, Manrope, DM_Mono } from "next/font/google";
import "./globals.css";

const syne = Syne({ subsets: ["latin"], variable: "--font-syne", weight: ["400","500","600","700","800"] });
const manrope = Manrope({ subsets: ["latin"], variable: "--font-manrope", weight: ["300","400","500","600","700"] });
const dmMono = DM_Mono({ subsets: ["latin"], variable: "--font-mono", weight: ["300","400","500"] });

export const metadata: Metadata = {
  title: "Husnain Raza — Senior JavaScript Developer",
  description: "Full Stack JavaScript Developer specializing in React, Next.js, and Node.js. Building high-performance web applications in Lahore, Pakistan.",
  keywords: ["JavaScript Developer", "React Developer", "Next.js", "Node.js", "Full Stack", "Lahore"],
  openGraph: {
    title: "Husnain Raza — Senior JavaScript Developer",
    description: "Full Stack JavaScript Developer · React · Node.js · 4+ Years Experience",
    type: "website",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className={`${syne.variable} ${manrope.variable} ${dmMono.variable} font-manrope`}>
        {children}
      </body>
    </html>
  );
}
